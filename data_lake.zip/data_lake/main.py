# main.py

from organized import organize_files_by_type
from analyze import analyze_word_frequency_from_folder


source_folder = 'source_files'
raw_folder = 'raw'

organize_files_by_type(source_folder, raw_folder)

result = analyze_word_frequency_from_folder('raw/txt')
print("\n[Top Words]")
for word, count in result.items():
    print(f'"{word}": {count}')