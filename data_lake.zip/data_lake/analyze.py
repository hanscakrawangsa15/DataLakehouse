# analyze.py

import os
import re
from collections import Counter

def analyze_word_frequency_from_folder(folder_path: str, top_n: int = 30) -> dict:
    """
    Membaca semua file .txt dalam folder, membersihkan, dan menghitung frekuensi kata.
    Mengembalikan top_n kata paling sering dalam format dict.
    """
    if not os.path.exists(folder_path):
        print(f"[ERROR] Folder tidak ditemukan: {folder_path}")
        return {}

    all_words = []

    # Baca semua file .txt dalam folder
    for filename in os.listdir(folder_path):
        if filename.endswith('.txt'):
            file_path = os.path.join(folder_path, filename)
            with open(file_path, 'r', encoding='utf-8') as file:
                lines = file.readlines()

            for line in lines:
                line = re.sub(r'@\w+', '', line)  # Hapus mention Twitter
                words = re.findall(r'\b\w+\b', line.lower())  # Ambil kata
                all_words.extend(words)

    word_counts = Counter(all_words)

    # Stopwords dasar (bisa diperluas)
    stopwords = set([
        "the", "and", "of", "a", "in", "to", "for", "is", "on", "it",
        "with", "my", "at", "you", "this", "just", "so", "from", "that", "be",
        "an", "as", "are", "but", "i", "was", "your", "if", "or", "not", "do"
    ])
    for word in list(word_counts):
        if word in stopwords:
            del word_counts[word]

    top_words = dict(word_counts.most_common(top_n))
    return top_words

